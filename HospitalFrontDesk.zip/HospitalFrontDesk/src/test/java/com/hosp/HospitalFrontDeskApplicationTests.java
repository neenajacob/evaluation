/*
 * Hospital Front Desk 
 */
package com.hosp;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.hosp.controller.HospFrontDeskController;
import com.hosp.entity.RestClient;
import com.hosp.error.ResourceNotFoundException;
import com.hosp.service.HospitalServiceException;

// TODO: Auto-generated Javadoc
/**
 * The Class HospitalFrontDeskApplicationTests.
 */
@SpringBootTest
class HospitalFrontDeskApplicationTests {

	@Autowired
	HospFrontDeskController hfdc;

	/**
	 * Context loads.
	 */
	@Test
	void contextLoads() {
	}

	@Test
	public void testGetHospSpecialistDetails() {
		try {
			hfdc.getHospSpecialistDetails("Apollo", "dentist");
		} catch (HospitalServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void testGetHospSpecialistDetailsException() {
		try {
			hfdc.getHospSpecialistDetails("Apollo", "dentis");
		} catch (HospitalServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void getAppointment() {

		try {
			hfdc.getAppointment("Deepak", "Saturday", "Neena");
		} catch (ResourceNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Test
	public void getBedsAvailable() {

		try {
			hfdc.getBedsAvailable("Apollo");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	/**
	 * Rest client.
	 */
	@Test
	public void restClient() {

		try {
			RestClient rc = new RestClient("8080", "test", "GET",
					"http://localhost:8080/api/specialists/{hospitalName}/{specialistType}", 925, "dentist");
			hfdc.restClient(rc);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
