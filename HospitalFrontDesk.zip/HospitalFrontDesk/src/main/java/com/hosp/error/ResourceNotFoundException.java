/*
 * Hospital Front Desk 
 */
package com.hosp.error;

// TODO: Auto-generated Javadoc
/**
 * The Class ResourceNotFoundException.
 */
public class ResourceNotFoundException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = -9079454849611061074L;

	/**
	 * Instantiates a new resource not found exception.
	 */
	public ResourceNotFoundException() {
		super();
	}

	/**
	 * Instantiates a new resource not found exception.
	 *
	 * @param message the message
	 */
	public ResourceNotFoundException(final String message) {
		super(message);
	}

}
