/*
 * Hospital Front Desk 
 */
package com.hosp.error;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.hosp.service.HospitalServiceException;

// TODO: Auto-generated Javadoc
/**
 * The Class HospFDExceptionManager.
 */
@ControllerAdvice
public class HospFDExceptionManager extends ResponseEntityExceptionHandler {

	/**
	 * Handle resource not found.
	 *
	 * @param exception the exception
	 * @param request the request
	 * @return the exception response
	 */
	@ExceptionHandler(ResourceNotFoundException.class)
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	public @ResponseBody ExceptionResponse handleResourceNotFound(final ResourceNotFoundException exception,
			final HttpServletRequest request) {

		ExceptionResponse error = new ExceptionResponse();
		error.setErrorMessage(exception.getMessage());
		error.callerURL(request.getRequestURI());

		return error;
	}

	/**
	 * Handle exception.
	 *
	 * @param exception the exception
	 * @param request the request
	 * @return the exception response
	 */
	@ExceptionHandler(Exception.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public @ResponseBody ExceptionResponse handleException(final Exception exception,
			final HttpServletRequest request) {

		ExceptionResponse error = new ExceptionResponse();
		error.setErrorMessage(exception.getMessage());
		error.callerURL(request.getRequestURI());

		return error;
	}

	/**
	 * Handle hosp service exception.
	 *
	 * @param exception the exception
	 * @param request the request
	 * @return the exception response
	 */
	@ExceptionHandler(HospitalServiceException.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	public @ResponseBody ExceptionResponse handleHospServiceException(final Exception exception,
			final HttpServletRequest request) {

		ExceptionResponse error = new ExceptionResponse();
		error.setErrorMessage("HospitalServiceException : " + exception.getMessage());
		error.callerURL(request.getRequestURI());

		return error;
	}

}
