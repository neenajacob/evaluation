/*
 * Hospital Front Desk 
 */
package com.hosp.error;

// TODO: Auto-generated Javadoc
/**
 * The Class ExceptionResponse.
 */
public class ExceptionResponse {

	/** The error message. */
	private String errorMessage;
	
	/** The requested URI. */
	private String requestedURI;

	/**
	 * Gets the error message.
	 *
	 * @return the error message
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * Sets the error message.
	 *
	 * @param errorMessage the new error message
	 */
	public void setErrorMessage(final String errorMessage) {
		this.errorMessage = errorMessage;
	}

	/**
	 * Gets the requested URI.
	 *
	 * @return the requested URI
	 */
	public String getRequestedURI() {
		return requestedURI;
	}

	/**
	 * Caller URL.
	 *
	 * @param requestedURI the requested URI
	 */
	public void callerURL(final String requestedURI) {
		this.requestedURI = requestedURI;
	}

}
