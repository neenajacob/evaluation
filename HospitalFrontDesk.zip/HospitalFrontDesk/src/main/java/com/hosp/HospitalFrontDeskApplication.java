/*
 * Hospital Front Desk 
 */
package com.hosp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

// TODO: Auto-generated Javadoc
/**
 * The Class HospitalFrontDeskApplication.
 *
 * @author Neena Jacob
 */
@SpringBootApplication
@EnableCaching
public class HospitalFrontDeskApplication {

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 */
	public static void main(String[] args) {
		SpringApplication.run(HospitalFrontDeskApplication.class, args);

	}

	/**
	 * Gets the rest template.
	 *
	 * @return the rest template
	 */
	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();

	}

}
