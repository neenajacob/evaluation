/*
 * Hospital Front Desk 
 */
package com.hosp.service;

import java.time.DayOfWeek;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.hosp.config.AppConfig;
import com.hosp.config.PATIENT_STATUS;
import com.hosp.config.PATIENT_TYPE;
import com.hosp.config.SpecialistConfigClass;
import com.hosp.entity.Booking;
import com.hosp.entity.Hospital;
import com.hosp.entity.Item;
import com.hosp.entity.Patient;
import com.hosp.entity.Specialist;
import com.hosp.error.ResourceNotFoundException;

// TODO: Auto-generated Javadoc
/**
 * The Class HospitalService.
 */
@Service
public class HospitalService {
	
	/** The sc. */
	@Autowired
	SpecialistConfigClass sc;

	/** The rest template. */
	@Autowired
	RestTemplate restTemplate;

	/** The app config. */
	@Autowired
	AppConfig appConfig;

	/** The Constant GETSPECIALISTSURL. */
	@Value("${getSpecialistDetails}")
	private static final String GETSPECIALISTSURL = "";

	/**
	 * Gets the hospital specialist details.
	 *
	 * @param hospName the hosp name
	 * @param type the type
	 * @return the hospital specialist details
	 * @throws HospitalServiceException the hospital service exception
	 */
	public List<Item> getHospitalSpecialistDetails(String hospName, String type) throws HospitalServiceException {
		try {
			if (hospName == null || type == null) {
				throw new ResourceNotFoundException("Hospital Name/ Specialist Type cannot be empty");
			}
			List<Specialist> l = Arrays.asList(sc.getSpecialist());

			if (!l.stream().anyMatch(x -> x.getHospname().equalsIgnoreCase(hospName))) {
				throw new ResourceNotFoundException("Invalid Hospital Name");
			}
			if (!l.stream().anyMatch(h -> h.getType().equalsIgnoreCase(type))) {
				throw new ResourceNotFoundException("Invalid Specialist Type");
			}

			
			List<Specialist> splList = l.stream()
					.filter(s -> s.getHospname().equalsIgnoreCase(hospName) && s.getType().equalsIgnoreCase(type))
					.collect(Collectors.toList());
				
			System.out.println("splList" + splList.toString());
			List<Item> itemList = new ArrayList<Item>();
			splList.forEach(s -> itemList.add(new Item(s.getType(), s.getName(), s.getAvailableday(),
					s.getAvailabletime(), s.getIsavailable(), s.getHospid())));
			if (!itemList.stream().anyMatch(s -> s.getType().equalsIgnoreCase(type))) {
				throw new ResourceNotFoundException(
						"No Specialist Details found for Hospital Name:" + hospName + "  and Specialist Type:" + type);
			}
			System.out.println("itemList" + itemList.toString());
			return itemList;
		} catch (Exception e) {
			throw new HospitalServiceException(e.getMessage());

		}

	}

	/**
	 * Book appointment.
	 *
	 * @param sname the sname
	 * @param aday the aday
	 * @param patientname the patientname
	 * @return the booking
	 * @throws ResourceNotFoundException the resource not found exception
	 */
	public Booking bookAppointment(String sname, String aday, String patientname) throws ResourceNotFoundException {
		List<Specialist> l = Arrays.asList(sc.getSpecialist());

		// Validate specialist/aday/pname details
		//System.out.println("enum"+);
		try {
			if(DayOfWeek.valueOf(aday.toUpperCase()).name() == null){
				throw new ResourceNotFoundException("Appointment Day should be a day in the week, please spell check/correct any typo");
			}
		} catch (Exception e) {
			throw new ResourceNotFoundException("Appointment Day should be a day in the week, please spell check/correct any typo");
		}
		if (!l.stream().anyMatch(s -> s.getName().equalsIgnoreCase(sname))) {
			throw new ResourceNotFoundException("Specialist Details Not found - Please enter a valid Specialist Name");
		} else if (l.stream()
				.anyMatch(s -> s.getName().equalsIgnoreCase(sname) && s.getIsavailable().equalsIgnoreCase("N"))) {
			throw new ResourceNotFoundException("Specialist is Not Available, Please check later");
		} else if (!l.stream()
				.anyMatch(s -> s.getName().equalsIgnoreCase(sname) && s.getAvailableday().contains(aday))) {
			throw new ResourceNotFoundException("Specialist is Not Available on requested day:" + aday);
		}

		Stream<Specialist> d = l.stream()
				.filter(s -> s.getName().equalsIgnoreCase(sname) && s.getAvailableday().contains(aday));
		List<Specialist> f = d.collect(Collectors.toList());
		String appointmentTime = f.get(0).getAvailabletime();

		Booking bukng = new Booking(aday, appointmentTime, sname, patientname);

		//

		return bukng;

	}

	/**
	 * Gets the available bedsfor admission.
	 *
	 * @param hospName the hosp name
	 * @return the available bedsfor admission
	 * @throws ResourceNotFoundException 
	 */
	public String getAvailableBedsforAdmission(String hospName) throws ResourceNotFoundException {

		List<Patient> patientList = setpatientAndHospDetails();

		List<Patient> pr = patientList.stream()
				.filter(s -> s.getPatientStatus().equalsIgnoreCase(PATIENT_STATUS.DISCHARGE.name())
						&& s.getHospName().equalsIgnoreCase(hospName))
				.collect(Collectors.toList());

		Hospital hosp1 = new Hospital("Apollo", 100, patientList.stream()
				.filter(s -> s.getHospName().equalsIgnoreCase("Apollo")).collect(Collectors.toList()));
		Hospital hosp2 = new Hospital("AIMS", 70, patientList.stream()
				.filter(s -> s.getHospName().equalsIgnoreCase("Apollo")).collect(Collectors.toList()));
		List<Hospital> hlist = Arrays.asList(hosp1, hosp2);
		if(hlist.stream().noneMatch(h->h.getHospName().equalsIgnoreCase(hospName))) {
			throw new ResourceNotFoundException("Invalid hospital name - Please enter a valid hospital name");
		}
		int noOfBedsAvailable = pr.size();
		if(noOfBedsAvailable==0) {
			throw new ResourceNotFoundException("No beds are available for admission at hospital : "+hospName.toUpperCase());	
		}
		return "Number of Beds Available is = " + noOfBedsAvailable;
	}

	/**
	 * Rest client.
	 *
	 * @param port the port
	 * @param environment the environment
	 * @param type the type
	 * @param url the url
	 * @param hospitalId the hospital id
	 * @param specialistType the specialist type
	 * @return the list
	 */
	public List<ResponseEntity<Item[]>> restClient(String port, String environment, String type, String url,
			int hospitalId, String specialistType) {

		List<Specialist> l = Arrays.asList(sc.getSpecialist());
		List<Specialist> pr = l.stream().filter(s -> s.getHospid() == hospitalId).collect(Collectors.toList());
		String hospName = pr.get(0).getHospname();
		// HttpEntity<Item[]> h =new HttpEntity<Item[]>(new
		// HttpHeaders().setContentType(type));
		ResponseEntity<Item[]> obj = restTemplate.getForEntity(
				"http://localhost:8080/api/specialists/{hospitalName}/{specialistType}", Item[].class, hospName,
				specialistType);
		return Arrays.asList(obj);

	}

	/**
	 * Setpatient and hosp details.
	 *
	 * @return the list
	 */
	public List<Patient> setpatientAndHospDetails() {
		Patient p1 = new Patient("Swathy", PATIENT_STATUS.ADMITTED.name(), PATIENT_TYPE.INPATIENT.name(), "Apollo");
		Patient p2 = new Patient("Twinke", PATIENT_STATUS.DISCHARGE.name(), PATIENT_TYPE.INPATIENT.name(), "Apollo");
		Patient p3 = new Patient("Preety", PATIENT_STATUS.ADMITTED.name(), PATIENT_TYPE.INPATIENT.name(), "AIMS");
		Patient p4 = new Patient("John", PATIENT_STATUS.ADMITTED.name(), PATIENT_TYPE.INPATIENT.name(), "Apollo");
		Patient p5 = new Patient("JaMES", PATIENT_STATUS.ADMITTED.name(), PATIENT_TYPE.INPATIENT.name(), "AIMS");
		Patient p6 = new Patient("kARAN", PATIENT_STATUS.ADMITTED.name(), PATIENT_TYPE.INPATIENT.name(), "Apollo");
		List<Patient> patientList = Arrays.asList(p1, p2, p3, p4, p5, p6);

		return patientList;
	}
}
