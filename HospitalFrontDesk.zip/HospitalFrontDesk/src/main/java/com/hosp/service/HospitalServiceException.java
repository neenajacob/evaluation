/*
 * Hospital Front Desk 
 */
package com.hosp.service;

// TODO: Auto-generated Javadoc
/**
 * The Class HospitalServiceException.
 */
public class HospitalServiceException extends Exception {

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1L;

	/**
	 * Instantiates a new hospital service exception.
	 */
	public HospitalServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * Instantiates a new hospital service exception.
	 *
	 * @param arg0 the arg 0
	 * @param arg1 the arg 1
	 * @param arg2 the arg 2
	 * @param arg3 the arg 3
	 */
	public HospitalServiceException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	/**
	 * Instantiates a new hospital service exception.
	 *
	 * @param arg0 the arg 0
	 * @param arg1 the arg 1
	 */
	public HospitalServiceException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	/**
	 * Instantiates a new hospital service exception.
	 *
	 * @param arg0 the arg 0
	 */
	public HospitalServiceException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	/**
	 * Instantiates a new hospital service exception.
	 *
	 * @param arg0 the arg 0
	 */
	public HospitalServiceException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	
}
