/*
 * Hospital Front Desk 
 */
package com.hosp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hosp.config.AppConfig;
import com.hosp.entity.Booking;
import com.hosp.entity.Item;
import com.hosp.entity.RestClient;
import com.hosp.error.ResourceNotFoundException;
import com.hosp.service.HospitalService;
import com.hosp.service.HospitalServiceException;

// TODO: Auto-generated Javadoc
/**
 * The Class HospFrontDeskController.
 *
 * @author Neena Jacob
 */
@RestController
@RequestMapping("/api/")
public class HospFrontDeskController {

	/** The appconfig. */
	@Autowired
	AppConfig appconfig;

	/** The hosp service. */
	@Autowired
	HospitalService hospService;

	/**
	 * Gets the hosp specialist details.
	 *
	 * @param hospName the hosp name
	 * @param type the type
	 * @return the hosp specialist details
	 * @throws HospitalServiceException the hospital service exception
	 */
	@GetMapping(value = "${getSpecialistDetails}", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE })
	@Cacheable(value = "specialistdetails")
	public List<Item> getHospSpecialistDetails(@PathVariable("hospitalName") String hospName,
			@PathVariable("specialistType") String type) throws HospitalServiceException {

		System.out.println("inout" + hospName);

		try {
			return hospService.getHospitalSpecialistDetails(hospName, type);
		} catch (HospitalServiceException e) {

			throw new HospitalServiceException(e.getMessage());
		}

	}

	/**
	 * Gets the appointment.
	 *
	 * @param specialistName the specialist name
	 * @param appointmentDay the appointment day
	 * @param patientName the patient name
	 * @return the appointment
	 * @throws ResourceNotFoundException the resource not found exception
	 */
	@PostMapping(value = "${book}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public Booking getAppointment(@PathVariable("specialistName") String specialistName,
			@PathVariable("appointmentDay") String appointmentDay, @PathVariable("patientName") String patientName)
			throws ResourceNotFoundException {

		return hospService.bookAppointment(specialistName, appointmentDay, patientName);

	}

	/**
	 * Gets the beds available.
	 *
	 * @param hospitalName the hospital name
	 * @return the beds available
	 * @throws ResourceNotFoundException 
	 */
	@GetMapping(value = "${numberOfBedsForAdmission}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public String getBedsAvailable(@PathVariable("hospitalName") String hospitalName) throws ResourceNotFoundException {

		return hospService.getAvailableBedsforAdmission(hospitalName);

	}

	/**
	 * Rest client.
	 *
	 * @param rc the rc
	 * @return the list
	 */
	@PostMapping(value = "${restclientURL}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = {
			MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
	public List<ResponseEntity<Item[]>> restClient(@RequestBody RestClient rc) {

		return hospService.restClient(rc.getPort(), rc.getEnvironment(), rc.getType(), rc.getUrl(), rc.getHospitalId(),
				rc.getSpecialistType());

	}

}
