/*
 * Hospital Front Desk 
 */
package com.hosp.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

// TODO: Auto-generated Javadoc
/**
 * The Class AppConfig.
 */
@Component
@ConfigurationProperties
@PropertySource("classpath:application.properties")
public class AppConfig {

	/** The get specialist details. */
	private String getSpecialistDetails;

	/** The book. */
	private String book;
	
	/** The number of beds for admission. */
	private String numberOfBedsForAdmission;
	
	/** The restclient URL. */
	private String restclientURL;

	/**
	 * Gets the gets the specialist details.
	 *
	 * @return the gets the specialist details
	 */
	public String getGetSpecialistDetails() {
		return getSpecialistDetails;
	}

	/**
	 * Sets the gets the specialist details.
	 *
	 * @param getSpecialistDetails the new gets the specialist details
	 */
	public void setGetSpecialistDetails(String getSpecialistDetails) {
		this.getSpecialistDetails = getSpecialistDetails;
	}

	/**
	 * Gets the book.
	 *
	 * @return the book
	 */
	public String getBook() {
		return book;
	}

	/**
	 * Sets the book.
	 *
	 * @param book the new book
	 */
	public void setBook(String book) {
		this.book = book;
	}

	/**
	 * Gets the number of beds for admission.
	 *
	 * @return the number of beds for admission
	 */
	public String getNumberOfBedsForAdmission() {
		return numberOfBedsForAdmission;
	}

	/**
	 * Sets the number of beds for admission.
	 *
	 * @param numberOfBedsForAdmission the new number of beds for admission
	 */
	public void setNumberOfBedsForAdmission(String numberOfBedsForAdmission) {
		this.numberOfBedsForAdmission = numberOfBedsForAdmission;
	}

	/**
	 * Gets the restclient URL.
	 *
	 * @return the restclient URL
	 */
	public String getRestclientURL() {
		return restclientURL;
	}

	/**
	 * Sets the restclient URL.
	 *
	 * @param restclientURL the new restclient URL
	 */
	public void setRestclientURL(String restclientURL) {
		this.restclientURL = restclientURL;
	}

}
