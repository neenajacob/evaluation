/*
 * Hospital Front Desk 
 */
package com.hosp.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import com.hosp.entity.Specialist;

// TODO: Auto-generated Javadoc
/**
 * The Class SpecialistConfigClass.
 */
@Component
@ConfigurationProperties
@PropertySource("file:c:/properties/specialist.properties")
public class SpecialistConfigClass {
	
	/** The specialist. */
	private Specialist[] specialist;

	/**
	 * Gets the specialist.
	 *
	 * @return the specialist
	 */
	public Specialist[] getSpecialist() {
		return specialist;
	}

	/**
	 * Sets the specialist.
	 *
	 * @param specialist the new specialist
	 */
	public void setSpecialist(Specialist[] specialist) {
		this.specialist = specialist;
	}

}
