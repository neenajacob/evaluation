/*
 * Hospital Front Desk 
 */
package com.hosp.config;

// TODO: Auto-generated Javadoc
/**
 * The Enum PATIENT_STATUS.
 */
public enum PATIENT_STATUS {/** The discharge. */
DISCHARGE,/** The admitted. */
ADMITTED}
