/*
 * Hospital Front Desk 
 */
package com.hosp.config;

// TODO: Auto-generated Javadoc
/**
 * The Enum PATIENT_TYPE.
 */
public enum PATIENT_TYPE {

/** The inpatient. */
INPATIENT,
/** The outpatient. */
OUTPATIENT
}
