/*
 * Hospital Front Desk 
 */
package com.hosp.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class Item.
 */
public class Item {

	/** The type. */
	private String type;

	/** The name. */
	private String name;

	/** The availableday. */
	private String availableday;

	/** The available time. */
	private String availableTime;

	/** The is available. */
	private String isAvailable;
	
	/** The hospital id. */
	private int hospitalId;

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Sets the type.
	 *
	 * @param type the new type
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the availableday.
	 *
	 * @return the availableday
	 */
	public String getAvailableday() {
		return availableday;
	}

	/**
	 * Sets the availableday.
	 *
	 * @param availableday the new availableday
	 */
	public void setAvailableday(String availableday) {
		this.availableday = availableday;
	}

	/**
	 * Gets the available time.
	 *
	 * @return the available time
	 */
	public String getAvailableTime() {
		return availableTime;
	}

	/**
	 * Sets the available time.
	 *
	 * @param availableTime the new available time
	 */
	public void setAvailableTime(String availableTime) {
		this.availableTime = availableTime;
	}

	/**
	 * Gets the checks if is available.
	 *
	 * @return the checks if is available
	 */
	public String getIsAvailable() {
		return isAvailable;
	}

	/**
	 * Sets the checks if is available.
	 *
	 * @param isAvailable the new checks if is available
	 */
	public void setIsAvailable(String isAvailable) {
		this.isAvailable = isAvailable;
	}

	/**
	 * Gets the hospital id.
	 *
	 * @return the hospital id
	 */
	public int getHospitalId() {
		return hospitalId;
	}

	/**
	 * Sets the hospital id.
	 *
	 * @param hospitalId the new hospital id
	 */
	public void setHospitalId(int hospitalId) {
		this.hospitalId = hospitalId;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "Item [type=" + type + ", name=" + name + ", availableday=" + availableday + ", availableTime="
				+ availableTime + ", isAvailable=" + isAvailable + ", hospitalId=" + hospitalId + "]";
	}

	/**
	 * Instantiates a new item.
	 *
	 * @param type the type
	 * @param name the name
	 * @param availableday the availableday
	 * @param availableTime the available time
	 * @param isAvailable the is available
	 * @param hospitalId the hospital id
	 */
	public Item(String type, String name, String availableday, String availableTime, String isAvailable,
			int hospitalId) {
		super();
		this.type = type;
		this.name = name;
		this.availableday = availableday;
		this.availableTime = availableTime;
		this.isAvailable = isAvailable;
		this.hospitalId = hospitalId;
	}

	/**
	 * Instantiates a new item.
	 */
	public Item() {

	}

}
