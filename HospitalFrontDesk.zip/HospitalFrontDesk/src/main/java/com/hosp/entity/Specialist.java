/*
 * Hospital Front Desk 
 */
package com.hosp.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class Specialist.
 */
public class Specialist {

	/** The type. */
	private String type;
	
	/** The name. */
	private String name;
	
	/** The availableday. */
	private String availableday;
	
	/** The availabletime. */
	private String availabletime;
	
	/** The isavailable. */
	private String isavailable;
	
	/** The hospid. */
	private int hospid;
	
	/** The hospname. */
	private String hospname;

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Sets the type.
	 *
	 * @param type the new type
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * Gets the name.
	 *
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Sets the name.
	 *
	 * @param name the new name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gets the availableday.
	 *
	 * @return the availableday
	 */
	public String getAvailableday() {
		return availableday;
	}

	/**
	 * Sets the availableday.
	 *
	 * @param availableday the new availableday
	 */
	public void setAvailableday(String availableday) {
		this.availableday = availableday;
	}

	/**
	 * Gets the availabletime.
	 *
	 * @return the availabletime
	 */
	public String getAvailabletime() {
		return availabletime;
	}

	/**
	 * Sets the availabletime.
	 *
	 * @param availabletime the new availabletime
	 */
	public void setAvailabletime(String availabletime) {
		this.availabletime = availabletime;
	}

	/**
	 * Gets the isavailable.
	 *
	 * @return the isavailable
	 */
	public String getIsavailable() {
		return isavailable;
	}

	/**
	 * Sets the isavailable.
	 *
	 * @param isavailable the new isavailable
	 */
	public void setIsavailable(String isavailable) {
		this.isavailable = isavailable;
	}

	/**
	 * Gets the hospid.
	 *
	 * @return the hospid
	 */
	public int getHospid() {
		return hospid;
	}

	/**
	 * Sets the hospid.
	 *
	 * @param hospid the new hospid
	 */
	public void setHospid(int hospid) {
		this.hospid = hospid;
	}

	/**
	 * Gets the hospname.
	 *
	 * @return the hospname
	 */
	public String getHospname() {
		return hospname;
	}

	/**
	 * Sets the hospname.
	 *
	 * @param hospname the new hospname
	 */
	public void setHospname(String hospname) {
		this.hospname = hospname;
	}

	/**
	 * Instantiates a new specialist.
	 *
	 * @param type the type
	 * @param name the name
	 * @param availableday the availableday
	 * @param availabletime the availabletime
	 * @param isavailable the isavailable
	 * @param hospid the hospid
	 * @param hospname the hospname
	 */
	public Specialist(String type, String name, String availableday, String availabletime, String isavailable,
			int hospid, String hospname) {
		super();
		this.type = type;
		this.name = name;
		this.availableday = availableday;
		this.availabletime = availabletime;
		this.isavailable = isavailable;
		this.hospid = hospid;
		this.hospname = hospname;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "Specialist [type=" + type + ", name=" + name + ", availableday=" + availableday + ", availabletime="
				+ availabletime + ", isavailable=" + isavailable + ", hospid=" + hospid + ", hospname=" + hospname
				+ "]";
	}

	/**
	 * Instantiates a new specialist.
	 */
	public Specialist() {

	}

}