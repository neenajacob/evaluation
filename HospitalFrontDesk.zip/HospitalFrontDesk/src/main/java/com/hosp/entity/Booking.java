/*
 * Hospital Front Desk 
 */
package com.hosp.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class Booking.
 *
 * @author HP
 */
public class Booking {

	/** The specialist name. */
	private String specialistName;
	
	/** The patien name. */
	private String patienName;
	
	/** The appointment day. */
	private String appointmentDay;
	
	/** The appointment time. */
	private String appointmentTime;

	/**
	 * Gets the appointment day.
	 *
	 * @return the appointment day
	 */
	public String getAppointmentDay() {
		return appointmentDay;
	}

	/**
	 * Sets the appointment day.
	 *
	 * @param appointmentDay the new appointment day
	 */
	public void setAppointmentDay(String appointmentDay) {
		this.appointmentDay = appointmentDay;
	}

	/**
	 * Gets the appointment time.
	 *
	 * @return the appointment time
	 */
	public String getAppointmentTime() {
		return appointmentTime;
	}

	/**
	 * Sets the appointment time.
	 *
	 * @param appointmentTime the new appointment time
	 */
	public void setAppointmentTime(String appointmentTime) {
		this.appointmentTime = appointmentTime;
	}

	/**
	 * Gets the specialist name.
	 *
	 * @return the specialist name
	 */
	public String getSpecialistName() {
		return specialistName;
	}

	/**
	 * Sets the specialist name.
	 *
	 * @param specialistName the new specialist name
	 */
	public void setSpecialistName(String specialistName) {
		this.specialistName = specialistName;
	}

	/**
	 * Gets the patien name.
	 *
	 * @return the patien name
	 */
	public String getPatienName() {
		return patienName;
	}

	/**
	 * Sets the patien name.
	 *
	 * @param patienName the new patien name
	 */
	public void setPatienName(String patienName) {
		this.patienName = patienName;
	}

	/**
	 * Instantiates a new booking.
	 *
	 * @param appointmentDay the appointment day
	 * @param appointmentTime the appointment time
	 * @param specialistName the specialist name
	 * @param patienName the patien name
	 */
	public Booking(String appointmentDay, String appointmentTime, String specialistName, String patienName) {
		super();
		this.appointmentDay = appointmentDay;
		this.appointmentTime = appointmentTime;
		this.specialistName = specialistName;
		this.patienName = patienName;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "Booking [appointmentDay=" + appointmentDay + ", appointmentTime=" + appointmentTime
				+ ", specialistName=" + specialistName + ", patienName=" + patienName + "]";
	}

	/**
	 * Instantiates a new booking.
	 */
	public Booking() {

	}

}
