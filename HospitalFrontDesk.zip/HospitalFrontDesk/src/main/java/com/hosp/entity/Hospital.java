/*
 * Hospital Front Desk 
 */
package com.hosp.entity;

import java.util.List;

// TODO: Auto-generated Javadoc
/**
 * The Class Hospital.
 */
public class Hospital {

	/** The hosp id. */
	private int hospId;
	
	/** The hosp name. */
	private String hospName;
	
	/** The numberof beds. */
	private int numberofBeds;
	
		
	/** The patients. */
	private List<Patient> patients;

	/**
	 * Gets the hosp id.
	 *
	 * @return the hosp id
	 */
	public int getHospId() {
		return hospId;
	}

	/**
	 * Sets the hosp id.
	 *
	 * @param hospId the new hosp id
	 */
	public void setHospId(int hospId) {
		this.hospId = hospId;
	}

	/**
	 * Gets the hosp name.
	 *
	 * @return the hosp name
	 */
	public String getHospName() {
		return hospName;
	}

	/**
	 * Sets the hosp name.
	 *
	 * @param hospName the new hosp name
	 */
	public void setHospName(String hospName) {
		this.hospName = hospName;
	}

	/**
	 * Gets the numberof beds.
	 *
	 * @return the numberof beds
	 */
	public int getNumberofBeds() {
		return numberofBeds;
	}

	/**
	 * Sets the numberof beds.
	 *
	 * @param numberofBeds the new numberof beds
	 */
	public void setNumberofBeds(int numberofBeds) {
		this.numberofBeds = numberofBeds;
	}

	

	/**
	 * Gets the patients.
	 *
	 * @return the patients
	 */
	public List<Patient> getPatients() {
		return patients;
	}

	/**
	 * Sets the patients.
	 *
	 * @param patients the new patients
	 */
	public void setPatients(List<Patient> patients) {
		this.patients = patients;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "Hospital [hospId=" + hospId + ", hospName=" + hospName + ", numberofBeds=" + numberofBeds
				+ ",  patients=" + patients + "]";
	}

	/**
	 * Instantiates a new hospital.
	 *
	 * @param hospName the hosp name
	 * @param numberofBeds the numberof beds
	 * @param patients the patients
	 */
	public Hospital(String hospName, int numberofBeds,  List<Patient> patients) {
		super();
		this.hospName = hospName;
		this.numberofBeds = numberofBeds;
		//this.specialists = specialists;
		this.patients = patients;
	}

	/**
	 * Instantiates a new hospital.
	 */
	public Hospital() {
		
	}
	
	
	
}
