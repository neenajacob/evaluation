/*
 * Hospital Front Desk 
 */
package com.hosp.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class RestClient.
 */
public class RestClient {

	/** The port. */
	private String port;

	/** The environment. */
	private String environment;

	/** The type. */
	private String type;

	/** The url. */
	private String url;

	/** The hospital id. */
	private int hospitalId;

	/** The specialist type. */
	private String specialistType;

	/**
	 * Gets the port.
	 *
	 * @return the port
	 */
	public String getPort() {
		return port;
	}

	/**
	 * Sets the port.
	 *
	 * @param port the new port
	 */
	public void setPort(String port) {
		this.port = port;
	}

	/**
	 * Gets the environment.
	 *
	 * @return the environment
	 */
	public String getEnvironment() {
		return environment;
	}

	/**
	 * Sets the environment.
	 *
	 * @param environment the new environment
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	/**
	 * Gets the type.
	 *
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * Sets the type.
	 *
	 * @param type the new type
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * Gets the url.
	 *
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * Sets the url.
	 *
	 * @param url the new url
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * Gets the hospital id.
	 *
	 * @return the hospital id
	 */
	public int getHospitalId() {
		return hospitalId;
	}

	/**
	 * Sets the hospital id.
	 *
	 * @param hospitalId the new hospital id
	 */
	public void setHospitalId(int hospitalId) {
		this.hospitalId = hospitalId;
	}

	/**
	 * Gets the specialist type.
	 *
	 * @return the specialist type
	 */
	public String getSpecialistType() {
		return specialistType;
	}

	/**
	 * Sets the specialist type.
	 *
	 * @param specialistType the new specialist type
	 */
	public void setSpecialistType(String specialistType) {
		this.specialistType = specialistType;
	}

	/**
	 * Instantiates a new rest client.
	 *
	 * @param port the port
	 * @param environment the environment
	 * @param type the type
	 * @param url the url
	 * @param hospitalId the hospital id
	 * @param specialistType the specialist type
	 */
	public RestClient(String port, String environment, String type, String url, int hospitalId, String specialistType) {
		super();
		this.port = port;
		this.environment = environment;
		this.type = type;
		this.url = url;
		this.hospitalId = hospitalId;
		this.specialistType = specialistType;
	}

	/**
	 * Instantiates a new rest client.
	 */
	public RestClient() {

	}

}
