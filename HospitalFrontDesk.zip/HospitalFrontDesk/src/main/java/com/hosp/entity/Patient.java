/*
 * Hospital Front Desk 
 */
package com.hosp.entity;

// TODO: Auto-generated Javadoc
/**
 * The Class Patient.
 *
 * @author Neena Jacob
 */
public class Patient {

	/** The patient name. */
	private String patientName;

	/** The patient status. */
	private String patientStatus;

	/** The patient type. */
	private String patientType;

	/** The hosp name. */
	private String hospName;

	/**
	 * Gets the patient name.
	 *
	 * @return the patient name
	 */
	public String getPatientName() {
		return patientName;
	}

	/**
	 * Sets the patient name.
	 *
	 * @param patientName the new patient name
	 */
	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	/**
	 * Gets the patient status.
	 *
	 * @return the patient status
	 */
	public String getPatientStatus() {
		return patientStatus;
	}

	/**
	 * Sets the patient status.
	 *
	 * @param patientStatus the new patient status
	 */
	public void setPatientStatus(String patientStatus) {
		this.patientStatus = patientStatus;
	}

	/**
	 * Gets the patient type.
	 *
	 * @return the patient type
	 */
	public String getPatientType() {
		return patientType;
	}

	/**
	 * Sets the patient type.
	 *
	 * @param patientType the new patient type
	 */
	public void setPatientType(String patientType) {
		this.patientType = patientType;
	}

	/**
	 * Gets the hosp name.
	 *
	 * @return the hosp name
	 */
	public String getHospName() {
		return hospName;
	}

	/**
	 * Sets the hosp name.
	 *
	 * @param hospName the new hosp name
	 */
	public void setHospName(String hospName) {
		this.hospName = hospName;
	}

	/**
	 * Instantiates a new patient.
	 *
	 * @param patientName the patient name
	 * @param patientStatus the patient status
	 * @param patientType the patient type
	 * @param hospName the hosp name
	 */
	public Patient(String patientName, String patientStatus, String patientType, String hospName) {
		super();
		this.patientName = patientName;
		this.patientStatus = patientStatus;
		this.patientType = patientType;
		this.hospName = hospName;
	}

	/**
	 * To string.
	 *
	 * @return the string
	 */
	@Override
	public String toString() {
		return "Patient [patientName=" + patientName + ", patientStatus=" + patientStatus + ", patientType="
				+ patientType + ", hospName=" + hospName + "]";
	}

	/**
	 * Instantiates a new patient.
	 */
	public Patient() {

	}

}
